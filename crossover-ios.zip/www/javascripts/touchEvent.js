var touch_flag;


var entry = function(config, callback){
	//String targetID, boolean vertical, String extent;
	this.targetID = config.targetID;
	this.vertical = config.vertical;
	this.extent = config.extent;
	(extent?"pricise":"rough");
}
